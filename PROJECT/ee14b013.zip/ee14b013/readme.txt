Name                      Aravind S
Roll number               EE14B013

PA code                   rlp_pa.py
Paper critique PDF        GANs-critique-ee14b013.pdf

GitHub profile            (Aravind-Suresh)[https://github.com/Aravind-Suresh]

Have a look into the following repositories
https://github.com/Aravind-Suresh/CS5011-ML-assignments
https://github.com/Aravind-Suresh/rl-feed
https://github.com/iitmcvg/eye-gaze
https://github.com/Aravind-Suresh/faze
https://github.com/Aravind-Suresh/SeeSharpNative
https://github.com/Aravind-Suresh/FaceSwap
https://github.com/Aravind-Suresh/eigenFaces

Open source contributions
https://github.com/opencv/opencv/pull/6141
https://github.com/opencv/opencv/pull/6205
https://github.com/opencv/opencv_contrib/pull/593
https://github.com/opencv/opencv/pull/6148
https://github.com/opencv/opencv_contrib/pull/549 ( under review )
